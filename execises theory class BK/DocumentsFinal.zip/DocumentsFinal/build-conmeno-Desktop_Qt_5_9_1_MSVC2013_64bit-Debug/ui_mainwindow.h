/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QPushButton *ExitBtn;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label;
    QLineEdit *AccountEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *PassEdit;
    QHBoxLayout *horizontalLayout;
    QPushButton *Loginbtn;
    QPushButton *Registerbtn;
    QPushButton *pushButton_11;
    QScrollArea *scrollArea_3;
    QWidget *scrollAreaWidgetContents_3;
    QLabel *BookName_3;
    QLabel *BookAuthor_3;
    QLabel *BookType_3;
    QLabel *BookRate_3;
    QLabel *BookDes_3;
    QGroupBox *groupBox_8;
    QPushButton *BookShow_11;
    QPushButton *BookShow_12;
    QPushButton *BookShow_13;
    QPushButton *BookShow_14;
    QPushButton *BookShow_15;
    QPushButton *BookShow_16;
    QPushButton *BookShow_17;
    QPushButton *BookShow_18;
    QPushButton *BookShow_19;
    QPushButton *BookShow_20;
    QWidget *layoutWidget_5;
    QHBoxLayout *horizontalLayout_14;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QWidget *page_2;
    QPushButton *LogOut;
    QGroupBox *groupBox;
    QPushButton *BookShow;
    QPushButton *BookShow_2;
    QPushButton *BookShow_3;
    QPushButton *BookShow_4;
    QPushButton *BookShow_5;
    QPushButton *BookShow_6;
    QPushButton *BookShow_7;
    QPushButton *BookShow_8;
    QPushButton *BookShow_9;
    QPushButton *BookShow_10;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QLabel *BookName;
    QLabel *BookAuthor;
    QLabel *BookType;
    QLabel *BookRate;
    QLabel *BookDes;
    QGroupBox *groupBox_2;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout;
    QLabel *Name;
    QLabel *ID;
    QLabel *AccName;
    QPushButton *ChangeInfo;
    QPushButton *OK;
    QPushButton *pushButton_4;
    QPushButton *AdminTab;
    QPushButton *blirarian_2;
    QPushButton *pushButton_5;
    QPushButton *Cart;
    QPushButton *SearchReader;
    QWidget *page_3;
    QGroupBox *groupBox_3;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout_8;
    QListWidget *listWidget;
    QListWidget *listWidget_2;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *pushButton_6;
    QPushButton *Exit;
    QGroupBox *groupBox_4;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QLabel *Name_2;
    QLabel *ID_2;
    QLabel *AccName_2;
    QPushButton *Reader;
    QPushButton *blirarian;
    QGroupBox *groupBox_7;
    QWidget *layoutWidget4;
    QVBoxLayout *verticalLayout_9;
    QLineEdit *lineEdit_3;
    QPushButton *blirarian_3;
    QLineEdit *lineEdit_4;
    QPushButton *blirarian_4;
    QWidget *page_4;
    QGroupBox *groupBox_5;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_4;
    QLabel *Name_3;
    QLabel *ID_3;
    QLabel *AccName_3;
    QPushButton *Reader111;
    QPushButton *Admin111;
    QPushButton *logoutblirarian;
    QPushButton *Admin111_2;
    QWidget *layoutWidget5;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout_10;
    QListWidget *listWidget_3;
    QListWidget *listWidget_4;
    QPushButton *accept;
    QWidget *layoutWidget6;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_7;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_12;
    QListWidget *listWidget_7;
    QListWidget *listWidget_8;
    QPushButton *pushButton_7;
    QPushButton *pushButton_9;
    QWidget *page_6;
    QComboBox *comboBox;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_2;
    QLabel *BookName_2;
    QLabel *BookAuthor_2;
    QLabel *BookType_2;
    QLabel *BookRate_2;
    QLabel *BookDes_2;
    QLabel *IDBook;
    QListWidget *listWidget_9;
    QPushButton *pushButton_10;
    QLineEdit *txtSearch;
    QPushButton *adcartsearch;
    QPushButton *Gtcartfromsearch;
    QPushButton *BackfromSearch;
    QWidget *page_5;
    QGroupBox *groupBox_6;
    QWidget *layoutWidget_4;
    QVBoxLayout *verticalLayout_6;
    QLabel *Name_4;
    QLabel *ID_4;
    QLabel *AccName_4;
    QPushButton *Back;
    QWidget *layoutWidget7;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_6;
    QHBoxLayout *horizontalLayout_11;
    QListWidget *listWidget_5;
    QListWidget *listWidget_6;
    QPushButton *pushButton_8;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(900, 900);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 0, 900, 900));
        stackedWidget->setStyleSheet(QStringLiteral("background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0, stop:0 rgba(255, 255, 255, 255), stop:1 rgba(255, 255, 255, 255));"));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        ExitBtn = new QPushButton(page);
        ExitBtn->setObjectName(QStringLiteral("ExitBtn"));
        ExitBtn->setGeometry(QRect(790, 800, 100, 30));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        ExitBtn->setFont(font);
        ExitBtn->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        layoutWidget = new QWidget(page);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(13, 10, 881, 38));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        QFont font1;
        font1.setFamily(QStringLiteral("Ravie"));
        font1.setPointSize(20);
        label_3->setFont(font1);
        label_3->setStyleSheet(QStringLiteral("color: rgb(0, 85, 0);"));

        horizontalLayout_5->addWidget(label_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);
        label->setStyleSheet(QStringLiteral("color: rgb(0, 255, 0);"));

        horizontalLayout_3->addWidget(label);

        AccountEdit = new QLineEdit(layoutWidget);
        AccountEdit->setObjectName(QStringLiteral("AccountEdit"));

        horizontalLayout_3->addWidget(AccountEdit);


        horizontalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFont(font);
        label_2->setStyleSheet(QStringLiteral("color: rgb(0, 255, 0);"));

        horizontalLayout_2->addWidget(label_2);

        PassEdit = new QLineEdit(layoutWidget);
        PassEdit->setObjectName(QStringLiteral("PassEdit"));
        PassEdit->setEchoMode(QLineEdit::Password);

        horizontalLayout_2->addWidget(PassEdit);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        Loginbtn = new QPushButton(layoutWidget);
        Loginbtn->setObjectName(QStringLiteral("Loginbtn"));
        QFont font2;
        font2.setFamily(QStringLiteral("Ravie"));
        Loginbtn->setFont(font2);
        Loginbtn->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));

        horizontalLayout->addWidget(Loginbtn);

        Registerbtn = new QPushButton(layoutWidget);
        Registerbtn->setObjectName(QStringLiteral("Registerbtn"));
        Registerbtn->setFont(font2);
        Registerbtn->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));

        horizontalLayout->addWidget(Registerbtn);


        horizontalLayout_4->addLayout(horizontalLayout);


        horizontalLayout_5->addLayout(horizontalLayout_4);

        pushButton_11 = new QPushButton(page);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(90, 800, 113, 32));
        pushButton_11->setFont(font);
        scrollArea_3 = new QScrollArea(page);
        scrollArea_3->setObjectName(QStringLiteral("scrollArea_3"));
        scrollArea_3->setGeometry(QRect(90, 390, 700, 300));
        scrollArea_3->setStyleSheet(QStringLiteral("background-color: rgb(85, 255, 0);"));
        scrollArea_3->setWidgetResizable(true);
        scrollAreaWidgetContents_3 = new QWidget();
        scrollAreaWidgetContents_3->setObjectName(QStringLiteral("scrollAreaWidgetContents_3"));
        scrollAreaWidgetContents_3->setGeometry(QRect(0, 0, 698, 298));
        BookName_3 = new QLabel(scrollAreaWidgetContents_3);
        BookName_3->setObjectName(QStringLiteral("BookName_3"));
        BookName_3->setGeometry(QRect(20, 20, 660, 30));
        BookAuthor_3 = new QLabel(scrollAreaWidgetContents_3);
        BookAuthor_3->setObjectName(QStringLiteral("BookAuthor_3"));
        BookAuthor_3->setGeometry(QRect(20, 60, 660, 30));
        BookType_3 = new QLabel(scrollAreaWidgetContents_3);
        BookType_3->setObjectName(QStringLiteral("BookType_3"));
        BookType_3->setGeometry(QRect(20, 100, 660, 30));
        BookRate_3 = new QLabel(scrollAreaWidgetContents_3);
        BookRate_3->setObjectName(QStringLiteral("BookRate_3"));
        BookRate_3->setGeometry(QRect(20, 140, 660, 30));
        BookDes_3 = new QLabel(scrollAreaWidgetContents_3);
        BookDes_3->setObjectName(QStringLiteral("BookDes_3"));
        BookDes_3->setGeometry(QRect(20, 179, 660, 101));
        scrollArea_3->setWidget(scrollAreaWidgetContents_3);
        groupBox_8 = new QGroupBox(page);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(90, 90, 700, 270));
        BookShow_11 = new QPushButton(groupBox_8);
        BookShow_11->setObjectName(QStringLiteral("BookShow_11"));
        BookShow_11->setGeometry(QRect(20, 20, 310, 30));
        QFont font3;
        font3.setFamily(QStringLiteral("Lucida Calligraphy"));
        BookShow_11->setFont(font3);
        BookShow_11->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_12 = new QPushButton(groupBox_8);
        BookShow_12->setObjectName(QStringLiteral("BookShow_12"));
        BookShow_12->setGeometry(QRect(20, 60, 310, 30));
        BookShow_12->setFont(font3);
        BookShow_12->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_13 = new QPushButton(groupBox_8);
        BookShow_13->setObjectName(QStringLiteral("BookShow_13"));
        BookShow_13->setGeometry(QRect(20, 100, 310, 30));
        BookShow_13->setFont(font3);
        BookShow_13->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_14 = new QPushButton(groupBox_8);
        BookShow_14->setObjectName(QStringLiteral("BookShow_14"));
        BookShow_14->setGeometry(QRect(20, 140, 310, 30));
        BookShow_14->setFont(font3);
        BookShow_14->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_15 = new QPushButton(groupBox_8);
        BookShow_15->setObjectName(QStringLiteral("BookShow_15"));
        BookShow_15->setGeometry(QRect(20, 180, 310, 30));
        BookShow_15->setFont(font3);
        BookShow_15->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_16 = new QPushButton(groupBox_8);
        BookShow_16->setObjectName(QStringLiteral("BookShow_16"));
        BookShow_16->setGeometry(QRect(370, 20, 310, 30));
        BookShow_16->setFont(font3);
        BookShow_16->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_17 = new QPushButton(groupBox_8);
        BookShow_17->setObjectName(QStringLiteral("BookShow_17"));
        BookShow_17->setGeometry(QRect(370, 60, 310, 30));
        BookShow_17->setFont(font3);
        BookShow_17->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_18 = new QPushButton(groupBox_8);
        BookShow_18->setObjectName(QStringLiteral("BookShow_18"));
        BookShow_18->setGeometry(QRect(370, 100, 310, 30));
        BookShow_18->setFont(font3);
        BookShow_18->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_19 = new QPushButton(groupBox_8);
        BookShow_19->setObjectName(QStringLiteral("BookShow_19"));
        BookShow_19->setGeometry(QRect(370, 140, 310, 30));
        BookShow_19->setFont(font3);
        BookShow_19->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_20 = new QPushButton(groupBox_8);
        BookShow_20->setObjectName(QStringLiteral("BookShow_20"));
        BookShow_20->setGeometry(QRect(370, 180, 310, 30));
        BookShow_20->setFont(font3);
        BookShow_20->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        layoutWidget_5 = new QWidget(groupBox_8);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(18, 230, 661, 32));
        horizontalLayout_14 = new QHBoxLayout(layoutWidget_5);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        pushButton_12 = new QPushButton(layoutWidget_5);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setStyleSheet(QLatin1String("border-color: rgb(0, 170, 0);\n"
"border-top-color: rgb(0, 255, 0);\n"
"border-widge: 2px;"));

        horizontalLayout_14->addWidget(pushButton_12);

        pushButton_13 = new QPushButton(layoutWidget_5);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));

        horizontalLayout_14->addWidget(pushButton_13);

        pushButton_14 = new QPushButton(layoutWidget_5);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));

        horizontalLayout_14->addWidget(pushButton_14);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        LogOut = new QPushButton(page_2);
        LogOut->setObjectName(QStringLiteral("LogOut"));
        LogOut->setGeometry(QRect(790, 800, 100, 30));
        LogOut->setFont(font);
        LogOut->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        groupBox = new QGroupBox(page_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(100, 150, 700, 270));
        BookShow = new QPushButton(groupBox);
        BookShow->setObjectName(QStringLiteral("BookShow"));
        BookShow->setGeometry(QRect(20, 20, 310, 30));
        BookShow->setFont(font3);
        BookShow->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_2 = new QPushButton(groupBox);
        BookShow_2->setObjectName(QStringLiteral("BookShow_2"));
        BookShow_2->setGeometry(QRect(20, 60, 310, 30));
        BookShow_2->setFont(font3);
        BookShow_2->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_3 = new QPushButton(groupBox);
        BookShow_3->setObjectName(QStringLiteral("BookShow_3"));
        BookShow_3->setGeometry(QRect(20, 100, 310, 30));
        BookShow_3->setFont(font3);
        BookShow_3->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_4 = new QPushButton(groupBox);
        BookShow_4->setObjectName(QStringLiteral("BookShow_4"));
        BookShow_4->setGeometry(QRect(20, 140, 310, 30));
        BookShow_4->setFont(font3);
        BookShow_4->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_5 = new QPushButton(groupBox);
        BookShow_5->setObjectName(QStringLiteral("BookShow_5"));
        BookShow_5->setGeometry(QRect(20, 180, 310, 30));
        BookShow_5->setFont(font3);
        BookShow_5->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_6 = new QPushButton(groupBox);
        BookShow_6->setObjectName(QStringLiteral("BookShow_6"));
        BookShow_6->setGeometry(QRect(370, 20, 310, 30));
        BookShow_6->setFont(font3);
        BookShow_6->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_7 = new QPushButton(groupBox);
        BookShow_7->setObjectName(QStringLiteral("BookShow_7"));
        BookShow_7->setGeometry(QRect(370, 60, 310, 30));
        BookShow_7->setFont(font3);
        BookShow_7->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_8 = new QPushButton(groupBox);
        BookShow_8->setObjectName(QStringLiteral("BookShow_8"));
        BookShow_8->setGeometry(QRect(370, 100, 310, 30));
        BookShow_8->setFont(font3);
        BookShow_8->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_9 = new QPushButton(groupBox);
        BookShow_9->setObjectName(QStringLiteral("BookShow_9"));
        BookShow_9->setGeometry(QRect(370, 140, 310, 30));
        BookShow_9->setFont(font3);
        BookShow_9->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        BookShow_10 = new QPushButton(groupBox);
        BookShow_10->setObjectName(QStringLiteral("BookShow_10"));
        BookShow_10->setGeometry(QRect(370, 180, 310, 30));
        BookShow_10->setFont(font3);
        BookShow_10->setStyleSheet(QStringLiteral("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0.039548 rgba(0, 247, 0, 255));"));
        layoutWidget1 = new QWidget(groupBox);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(18, 230, 661, 32));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget1);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout_6->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget1);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout_6->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget1);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout_6->addWidget(pushButton_3);

        scrollArea = new QScrollArea(page_2);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setGeometry(QRect(100, 450, 700, 300));
        scrollArea->setStyleSheet(QStringLiteral("background-color: rgb(85, 255, 0);"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 698, 298));
        BookName = new QLabel(scrollAreaWidgetContents);
        BookName->setObjectName(QStringLiteral("BookName"));
        BookName->setGeometry(QRect(20, 20, 660, 30));
        BookAuthor = new QLabel(scrollAreaWidgetContents);
        BookAuthor->setObjectName(QStringLiteral("BookAuthor"));
        BookAuthor->setGeometry(QRect(20, 60, 660, 30));
        BookType = new QLabel(scrollAreaWidgetContents);
        BookType->setObjectName(QStringLiteral("BookType"));
        BookType->setGeometry(QRect(20, 100, 660, 30));
        BookRate = new QLabel(scrollAreaWidgetContents);
        BookRate->setObjectName(QStringLiteral("BookRate"));
        BookRate->setGeometry(QRect(20, 140, 660, 30));
        BookDes = new QLabel(scrollAreaWidgetContents);
        BookDes->setObjectName(QStringLiteral("BookDes"));
        BookDes->setGeometry(QRect(20, 179, 660, 101));
        scrollArea->setWidget(scrollAreaWidgetContents);
        groupBox_2 = new QGroupBox(page_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(0, 0, 340, 150));
        groupBox_2->setStyleSheet(QStringLiteral(""));
        layoutWidget2 = new QWidget(groupBox_2);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(0, 10, 331, 141));
        verticalLayout = new QVBoxLayout(layoutWidget2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        Name = new QLabel(layoutWidget2);
        Name->setObjectName(QStringLiteral("Name"));

        verticalLayout->addWidget(Name);

        ID = new QLabel(layoutWidget2);
        ID->setObjectName(QStringLiteral("ID"));

        verticalLayout->addWidget(ID);

        AccName = new QLabel(layoutWidget2);
        AccName->setObjectName(QStringLiteral("AccName"));

        verticalLayout->addWidget(AccName);

        ChangeInfo = new QPushButton(layoutWidget2);
        ChangeInfo->setObjectName(QStringLiteral("ChangeInfo"));
        ChangeInfo->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout->addWidget(ChangeInfo);

        OK = new QPushButton(layoutWidget2);
        OK->setObjectName(QStringLiteral("OK"));
        OK->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout->addWidget(OK);

        pushButton_4 = new QPushButton(page_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(0, 0, 100, 30));
        pushButton_4->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));
        AdminTab = new QPushButton(page_2);
        AdminTab->setObjectName(QStringLiteral("AdminTab"));
        AdminTab->setGeometry(QRect(400, 30, 100, 30));
        AdminTab->setFont(font);
        blirarian_2 = new QPushButton(page_2);
        blirarian_2->setObjectName(QStringLiteral("blirarian_2"));
        blirarian_2->setGeometry(QRect(400, 90, 100, 30));
        blirarian_2->setFont(font);
        pushButton_5 = new QPushButton(page_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(100, 800, 100, 30));
        pushButton_5->setFont(font);
        Cart = new QPushButton(page_2);
        Cart->setObjectName(QStringLiteral("Cart"));
        Cart->setGeometry(QRect(280, 800, 100, 30));
        Cart->setFont(font);
        SearchReader = new QPushButton(page_2);
        SearchReader->setObjectName(QStringLiteral("SearchReader"));
        SearchReader->setGeometry(QRect(570, 60, 131, 32));
        SearchReader->setFont(font);
        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        groupBox_3 = new QGroupBox(page_3);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(0, 150, 600, 700));
        layoutWidget3 = new QWidget(groupBox_3);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(0, 10, 591, 681));
        verticalLayout_2 = new QVBoxLayout(layoutWidget3);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_4 = new QLabel(layoutWidget3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setStyleSheet(QLatin1String("font: 8pt \"Lucida Calligraphy\";\n"
"color: rgb(0, 255, 0);"));

        horizontalLayout_9->addWidget(label_4);

        lineEdit = new QLineEdit(layoutWidget3);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_9->addWidget(lineEdit);


        verticalLayout_2->addLayout(horizontalLayout_9);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        listWidget = new QListWidget(layoutWidget3);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        horizontalLayout_8->addWidget(listWidget);

        listWidget_2 = new QListWidget(layoutWidget3);
        listWidget_2->setObjectName(QStringLiteral("listWidget_2"));

        horizontalLayout_8->addWidget(listWidget_2);


        verticalLayout_2->addLayout(horizontalLayout_8);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        pushButton_6 = new QPushButton(layoutWidget3);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setStyleSheet(QLatin1String("color: rgb(255, 0, 0);\n"
"background-color: rgb(0, 255, 0);\n"
"font: 75 8pt \"MS Shell Dlg 2\";"));

        horizontalLayout_7->addWidget(pushButton_6);


        verticalLayout_2->addLayout(horizontalLayout_7);

        Exit = new QPushButton(page_3);
        Exit->setObjectName(QStringLiteral("Exit"));
        Exit->setGeometry(QRect(750, 800, 100, 30));
        Exit->setFont(font);
        Exit->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        groupBox_4 = new QGroupBox(page_3);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(0, 0, 340, 150));
        layoutWidget_2 = new QWidget(groupBox_4);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(0, 10, 331, 131));
        verticalLayout_3 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        Name_2 = new QLabel(layoutWidget_2);
        Name_2->setObjectName(QStringLiteral("Name_2"));

        verticalLayout_3->addWidget(Name_2);

        ID_2 = new QLabel(layoutWidget_2);
        ID_2->setObjectName(QStringLiteral("ID_2"));

        verticalLayout_3->addWidget(ID_2);

        AccName_2 = new QLabel(layoutWidget_2);
        AccName_2->setObjectName(QStringLiteral("AccName_2"));

        verticalLayout_3->addWidget(AccName_2);

        Reader = new QPushButton(page_3);
        Reader->setObjectName(QStringLiteral("Reader"));
        Reader->setGeometry(QRect(400, 30, 100, 30));
        Reader->setFont(font);
        blirarian = new QPushButton(page_3);
        blirarian->setObjectName(QStringLiteral("blirarian"));
        blirarian->setGeometry(QRect(400, 90, 100, 30));
        blirarian->setFont(font);
        groupBox_7 = new QGroupBox(page_3);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        groupBox_7->setGeometry(QRect(600, 160, 291, 191));
        layoutWidget4 = new QWidget(groupBox_7);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(0, 10, 291, 181));
        verticalLayout_9 = new QVBoxLayout(layoutWidget4);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        lineEdit_3 = new QLineEdit(layoutWidget4);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        verticalLayout_9->addWidget(lineEdit_3);

        blirarian_3 = new QPushButton(layoutWidget4);
        blirarian_3->setObjectName(QStringLiteral("blirarian_3"));
        blirarian_3->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout_9->addWidget(blirarian_3);

        lineEdit_4 = new QLineEdit(layoutWidget4);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        verticalLayout_9->addWidget(lineEdit_4);

        blirarian_4 = new QPushButton(layoutWidget4);
        blirarian_4->setObjectName(QStringLiteral("blirarian_4"));
        blirarian_4->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout_9->addWidget(blirarian_4);

        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        groupBox_5 = new QGroupBox(page_4);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(0, 0, 340, 150));
        layoutWidget_3 = new QWidget(groupBox_5);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(0, 10, 331, 131));
        verticalLayout_4 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        Name_3 = new QLabel(layoutWidget_3);
        Name_3->setObjectName(QStringLiteral("Name_3"));

        verticalLayout_4->addWidget(Name_3);

        ID_3 = new QLabel(layoutWidget_3);
        ID_3->setObjectName(QStringLiteral("ID_3"));

        verticalLayout_4->addWidget(ID_3);

        AccName_3 = new QLabel(layoutWidget_3);
        AccName_3->setObjectName(QStringLiteral("AccName_3"));

        verticalLayout_4->addWidget(AccName_3);

        Reader111 = new QPushButton(page_4);
        Reader111->setObjectName(QStringLiteral("Reader111"));
        Reader111->setGeometry(QRect(400, 30, 100, 30));
        Reader111->setFont(font);
        Admin111 = new QPushButton(page_4);
        Admin111->setObjectName(QStringLiteral("Admin111"));
        Admin111->setGeometry(QRect(400, 90, 100, 30));
        Admin111->setFont(font);
        logoutblirarian = new QPushButton(page_4);
        logoutblirarian->setObjectName(QStringLiteral("logoutblirarian"));
        logoutblirarian->setGeometry(QRect(750, 800, 100, 30));
        logoutblirarian->setFont(font);
        logoutblirarian->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        Admin111_2 = new QPushButton(page_4);
        Admin111_2->setObjectName(QStringLiteral("Admin111_2"));
        Admin111_2->setGeometry(QRect(560, 90, 100, 30));
        Admin111_2->setFont(font);
        layoutWidget5 = new QWidget(page_4);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(0, 190, 681, 241));
        verticalLayout_5 = new QVBoxLayout(layoutWidget5);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget5);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font3);
        label_5->setStyleSheet(QStringLiteral("color: rgb(0, 255, 0);"));

        verticalLayout_5->addWidget(label_5);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        listWidget_3 = new QListWidget(layoutWidget5);
        listWidget_3->setObjectName(QStringLiteral("listWidget_3"));

        horizontalLayout_10->addWidget(listWidget_3);

        listWidget_4 = new QListWidget(layoutWidget5);
        listWidget_4->setObjectName(QStringLiteral("listWidget_4"));

        horizontalLayout_10->addWidget(listWidget_4);


        verticalLayout_5->addLayout(horizontalLayout_10);

        accept = new QPushButton(layoutWidget5);
        accept->setObjectName(QStringLiteral("accept"));
        accept->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout_5->addWidget(accept);

        layoutWidget6 = new QWidget(page_4);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(0, 430, 681, 401));
        verticalLayout_8 = new QVBoxLayout(layoutWidget6);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        label_7 = new QLabel(layoutWidget6);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font3);
        label_7->setStyleSheet(QStringLiteral("color: rgb(0, 255, 0);"));

        horizontalLayout_13->addWidget(label_7);

        lineEdit_2 = new QLineEdit(layoutWidget6);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_13->addWidget(lineEdit_2);


        verticalLayout_8->addLayout(horizontalLayout_13);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        listWidget_7 = new QListWidget(layoutWidget6);
        listWidget_7->setObjectName(QStringLiteral("listWidget_7"));

        horizontalLayout_12->addWidget(listWidget_7);

        listWidget_8 = new QListWidget(layoutWidget6);
        listWidget_8->setObjectName(QStringLiteral("listWidget_8"));

        horizontalLayout_12->addWidget(listWidget_8);


        verticalLayout_8->addLayout(horizontalLayout_12);

        pushButton_7 = new QPushButton(layoutWidget6);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setFont(font3);
        pushButton_7->setStyleSheet(QLatin1String("color: rgb(255, 0, 0);\n"
"background-color: rgb(0, 255, 0);"));

        verticalLayout_8->addWidget(pushButton_7);

        pushButton_9 = new QPushButton(layoutWidget6);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setStyleSheet(QLatin1String("background-color: rgb(0, 170, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout_8->addWidget(pushButton_9);

        stackedWidget->addWidget(page_4);
        page_6 = new QWidget();
        page_6->setObjectName(QStringLiteral("page_6"));
        comboBox = new QComboBox(page_6);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(90, 40, 104, 26));
        scrollArea_2 = new QScrollArea(page_6);
        scrollArea_2->setObjectName(QStringLiteral("scrollArea_2"));
        scrollArea_2->setGeometry(QRect(80, 290, 671, 261));
        scrollArea_2->setStyleSheet(QStringLiteral("background-color: rgb(0, 255, 0);"));
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QStringLiteral("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 669, 259));
        BookName_2 = new QLabel(scrollAreaWidgetContents_2);
        BookName_2->setObjectName(QStringLiteral("BookName_2"));
        BookName_2->setGeometry(QRect(20, 20, 660, 30));
        BookAuthor_2 = new QLabel(scrollAreaWidgetContents_2);
        BookAuthor_2->setObjectName(QStringLiteral("BookAuthor_2"));
        BookAuthor_2->setGeometry(QRect(20, 60, 660, 30));
        BookType_2 = new QLabel(scrollAreaWidgetContents_2);
        BookType_2->setObjectName(QStringLiteral("BookType_2"));
        BookType_2->setGeometry(QRect(20, 100, 660, 30));
        BookRate_2 = new QLabel(scrollAreaWidgetContents_2);
        BookRate_2->setObjectName(QStringLiteral("BookRate_2"));
        BookRate_2->setGeometry(QRect(20, 140, 660, 30));
        BookDes_2 = new QLabel(scrollAreaWidgetContents_2);
        BookDes_2->setObjectName(QStringLiteral("BookDes_2"));
        BookDes_2->setGeometry(QRect(20, 180, 660, 100));
        IDBook = new QLabel(scrollAreaWidgetContents_2);
        IDBook->setObjectName(QStringLiteral("IDBook"));
        IDBook->setGeometry(QRect(20, 180, 660, 30));
        scrollArea_2->setWidget(scrollAreaWidgetContents_2);
        listWidget_9 = new QListWidget(page_6);
        listWidget_9->setObjectName(QStringLiteral("listWidget_9"));
        listWidget_9->setGeometry(QRect(90, 130, 491, 141));
        pushButton_10 = new QPushButton(page_6);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(610, 80, 113, 32));
        pushButton_10->setFont(font3);
        pushButton_10->setStyleSheet(QStringLiteral("background-color: rgb(0, 255, 0);"));
        txtSearch = new QLineEdit(page_6);
        txtSearch->setObjectName(QStringLiteral("txtSearch"));
        txtSearch->setGeometry(QRect(90, 80, 491, 41));
        adcartsearch = new QPushButton(page_6);
        adcartsearch->setObjectName(QStringLiteral("adcartsearch"));
        adcartsearch->setGeometry(QRect(100, 600, 100, 30));
        adcartsearch->setFont(font);
        Gtcartfromsearch = new QPushButton(page_6);
        Gtcartfromsearch->setObjectName(QStringLiteral("Gtcartfromsearch"));
        Gtcartfromsearch->setGeometry(QRect(250, 600, 100, 30));
        Gtcartfromsearch->setFont(font);
        BackfromSearch = new QPushButton(page_6);
        BackfromSearch->setObjectName(QStringLiteral("BackfromSearch"));
        BackfromSearch->setGeometry(QRect(400, 600, 100, 30));
        BackfromSearch->setFont(font);
        stackedWidget->addWidget(page_6);
        page_5 = new QWidget();
        page_5->setObjectName(QStringLiteral("page_5"));
        groupBox_6 = new QGroupBox(page_5);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(0, 0, 340, 150));
        layoutWidget_4 = new QWidget(groupBox_6);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(0, 10, 331, 131));
        verticalLayout_6 = new QVBoxLayout(layoutWidget_4);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        Name_4 = new QLabel(layoutWidget_4);
        Name_4->setObjectName(QStringLiteral("Name_4"));

        verticalLayout_6->addWidget(Name_4);

        ID_4 = new QLabel(layoutWidget_4);
        ID_4->setObjectName(QStringLiteral("ID_4"));

        verticalLayout_6->addWidget(ID_4);

        AccName_4 = new QLabel(layoutWidget_4);
        AccName_4->setObjectName(QStringLiteral("AccName_4"));

        verticalLayout_6->addWidget(AccName_4);

        Back = new QPushButton(page_5);
        Back->setObjectName(QStringLiteral("Back"));
        Back->setGeometry(QRect(750, 800, 100, 30));
        Back->setFont(font);
        layoutWidget7 = new QWidget(page_5);
        layoutWidget7->setObjectName(QStringLiteral("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(0, 180, 681, 661));
        verticalLayout_7 = new QVBoxLayout(layoutWidget7);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget7);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setStyleSheet(QLatin1String("color: rgb(0, 255, 0);\n"
"font: 8pt \"Lucida Calligraphy\";"));

        verticalLayout_7->addWidget(label_6);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        listWidget_5 = new QListWidget(layoutWidget7);
        listWidget_5->setObjectName(QStringLiteral("listWidget_5"));

        horizontalLayout_11->addWidget(listWidget_5);

        listWidget_6 = new QListWidget(layoutWidget7);
        listWidget_6->setObjectName(QStringLiteral("listWidget_6"));

        horizontalLayout_11->addWidget(listWidget_6);


        verticalLayout_7->addLayout(horizontalLayout_11);

        pushButton_8 = new QPushButton(layoutWidget7);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setStyleSheet(QLatin1String("background-color: rgb(0, 255, 0);\n"
"font: 75 8pt \"MS Shell Dlg 2\";"));

        verticalLayout_7->addWidget(pushButton_8);

        stackedWidget->addWidget(page_5);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 900, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        ExitBtn->setText(QApplication::translate("MainWindow", "EXIT", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "LIBPRO", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Account Name", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Password", Q_NULLPTR));
        Loginbtn->setText(QApplication::translate("MainWindow", "Login", Q_NULLPTR));
        Registerbtn->setText(QApplication::translate("MainWindow", "Register", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        BookName_3->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        BookAuthor_3->setText(QApplication::translate("MainWindow", "Author:", Q_NULLPTR));
        BookType_3->setText(QApplication::translate("MainWindow", "Type:", Q_NULLPTR));
        BookRate_3->setText(QApplication::translate("MainWindow", "Rate:", Q_NULLPTR));
        BookDes_3->setText(QApplication::translate("MainWindow", "Describe:", Q_NULLPTR));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "Book", Q_NULLPTR));
        BookShow_11->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_12->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_13->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_14->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_15->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_16->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_17->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_18->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_19->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_20->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("MainWindow", "HOT BOOK!", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("MainWindow", "NEW BOOK!", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("MainWindow", "OLD GOOD BOOK!", Q_NULLPTR));
        LogOut->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Book", Q_NULLPTR));
        BookShow->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_2->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_3->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_4->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_5->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_6->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_7->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_8->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_9->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        BookShow_10->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "HOT BOOK!", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "NEW BOOK!", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "OLD GOOD BOOK!", Q_NULLPTR));
        BookName->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        BookAuthor->setText(QApplication::translate("MainWindow", "Author:", Q_NULLPTR));
        BookType->setText(QApplication::translate("MainWindow", "Type:", Q_NULLPTR));
        BookRate->setText(QApplication::translate("MainWindow", "Rate:", Q_NULLPTR));
        BookDes->setText(QApplication::translate("MainWindow", "Describe:", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        Name->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        ID->setText(QApplication::translate("MainWindow", "ID:", Q_NULLPTR));
        AccName->setText(QApplication::translate("MainWindow", "Account:", Q_NULLPTR));
        ChangeInfo->setText(QApplication::translate("MainWindow", "Full Info", Q_NULLPTR));
        OK->setText(QApplication::translate("MainWindow", "OK", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "User Info", Q_NULLPTR));
        AdminTab->setText(QApplication::translate("MainWindow", "Admin Screen", Q_NULLPTR));
        blirarian_2->setText(QApplication::translate("MainWindow", "Blirarian", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Add to cart", Q_NULLPTR));
        Cart->setText(QApplication::translate("MainWindow", "Go to Cart", Q_NULLPTR));
        SearchReader->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Search User: ", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "Reset Password", Q_NULLPTR));
        Exit->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        Name_2->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        ID_2->setText(QApplication::translate("MainWindow", "ID:", Q_NULLPTR));
        AccName_2->setText(QApplication::translate("MainWindow", "Account:", Q_NULLPTR));
        Reader->setText(QApplication::translate("MainWindow", "Reader", Q_NULLPTR));
        blirarian->setText(QApplication::translate("MainWindow", "Blirarian", Q_NULLPTR));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        blirarian_3->setText(QApplication::translate("MainWindow", "Set blirarian Code", Q_NULLPTR));
        blirarian_4->setText(QApplication::translate("MainWindow", "Set admin Password", Q_NULLPTR));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        Name_3->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        ID_3->setText(QApplication::translate("MainWindow", "ID:", Q_NULLPTR));
        AccName_3->setText(QApplication::translate("MainWindow", "Account:", Q_NULLPTR));
        Reader111->setText(QApplication::translate("MainWindow", "Admin", Q_NULLPTR));
        Admin111->setText(QApplication::translate("MainWindow", "Reader", Q_NULLPTR));
        logoutblirarian->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        Admin111_2->setText(QApplication::translate("MainWindow", "Add Book", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "List of request", Q_NULLPTR));
        accept->setText(QApplication::translate("MainWindow", "Accept", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", " Search Book:  ", Q_NULLPTR));
        lineEdit_2->setText(QString());
        pushButton_7->setText(QApplication::translate("MainWindow", "Delete Book", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Change Info", Q_NULLPTR));
        BookName_2->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        BookAuthor_2->setText(QApplication::translate("MainWindow", "Author:", Q_NULLPTR));
        BookType_2->setText(QApplication::translate("MainWindow", "Type:", Q_NULLPTR));
        BookRate_2->setText(QApplication::translate("MainWindow", "Rate:", Q_NULLPTR));
        BookDes_2->setText(QApplication::translate("MainWindow", "Describe:", Q_NULLPTR));
        IDBook->setText(QApplication::translate("MainWindow", "IDBook:", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "search", Q_NULLPTR));
        adcartsearch->setText(QApplication::translate("MainWindow", "Add to Cart", Q_NULLPTR));
        Gtcartfromsearch->setText(QApplication::translate("MainWindow", "Go to cart", Q_NULLPTR));
        BackfromSearch->setText(QApplication::translate("MainWindow", "Back", Q_NULLPTR));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        Name_4->setText(QApplication::translate("MainWindow", "Name:", Q_NULLPTR));
        ID_4->setText(QApplication::translate("MainWindow", "ID:", Q_NULLPTR));
        AccName_4->setText(QApplication::translate("MainWindow", "Account:", Q_NULLPTR));
        Back->setText(QApplication::translate("MainWindow", "Back", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "List of request", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "Send Request", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
